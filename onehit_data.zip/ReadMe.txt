persid: patient's identificator
cancer: normal=0, low-grade=1, high-grade=2
part: cell image quadrant 
a_Smean, a_Sq, h_Sdq6, h_Sdq are quadrant's image parameters


onehitONLINE <-
function(maxit=100,eps=10^-6,normlow=1,prnt=1)
{

#dump("onehitONLINE","c:\\Projects\\AFM\\onehit\\onehitONLINE.r")
#normlow=1: discrimination of normal&low-grade versus high grade
#normlow=2: discrimination of normal versus low&high-grade
#da=read.csv("c:\\Projects\\AFM\\onehit\\dataClassification.csv")

da=read.csv("dataClassification.csv")
persid=as.character(da[,1])
cancer=da$cancer # 0=normal, 1=low-grade, 2=high-grade

tit="normal vs low&high grade cancer"
nam1="h_Sdq6";nam2="h_Sdq"
if(normlow==1) 
{	cancer[cancer==1]=0; #normal&low-grade versus high-grade
	tit="normal&low vs high-grade cancer"
	nam1="a_Sq";nam2="a_Sa"
}
cancer[cancer==2]=1	
cat("Number of normals =",length(unique(persid[cancer==0]))," number of cancers =",length(unique(persid[cancer==1])),"\n")
grade.nam=c("Normal","Low-grade","High grade")
X=matrix(as.numeric(unlist(da[,4:7])),nrow=nrow(da))

#Fisher scoring algorithm
singhit=function(y,id,X,eps=10^-6,maxit=100,prnt=0) # Fisher scoring algorithm for ML estimation of the single-hit logistic regression model
{
	m=ncol(X)
	uid=unique(id)
	N=length(uid) #number of individuals
	yuniq=rep(0,N)
	b.LR=coef(glm(y~X-1,family=binomial))
	H=matrix(NA,ncol=m,nrow=N)
	offs=rep(NA,N)
	for(i in 1:N)
	{
		yuniq[i]=unique(y[id==uid[i]])
		ni=length(yuniq[i])
		Xi=matrix(X[id==uid[i],],ncol=m)
		offs[i]=log(2^ni-1)
		H[i,]=colSums(Xi)*2^(ni-1)*ni/(2^ni-1)		
	}
	bit=b.LR
	for(it in 1:maxit)
	{
		loglik=0
		der=rep(0,m);F=matrix(0,ncol=m,nrow=m)
		for(i in 1:N)
		{
			yi=unique(y[id==uid[i]])
			Xi=matrix(X[id==uid[i],],ncol=m)
			ei=as.vector(exp(Xi%*%bit))
			qi=sum(log(1+ei))
			eii=ei/(1+ei)
			di=t(Xi)%*%eii
			loglik=loglik+yi*log(1-exp(-qi))-(1-yi)*qi
			der=der+(yi/(1-exp(-qi))-1)*di
			F=F+exp(-qi)/(1-exp(-qi))*di%*%t(di)
		}
		iF=solve(F)
		delta=iF%*%der
		for(idi in 0:100) #loop over halving the step size
		{
			idic=idi
			b.new=bit+delta*2^-idi
			loglik.new=0
			for(i in 1:N)
			{
				yi=unique(y[id==uid[i]])
				Xi=matrix(X[id==uid[i],],ncol=m)
				ei=as.vector(exp(Xi%*%b.new))
				qi=sum(log(1+ei))				
				eii=ei/(1+ei)
				di=t(Xi)%*%eii
				loglik.new=loglik.new+yi*log(1-exp(-qi))-(1-yi)*qi				
			}
			if(!is.na(loglik.new))
			{
				if(loglik.new>loglik) break
			}
		}
		if(prnt) print(c(it,idic,loglik,b.new,sum(abs(der))))
		if(max(abs(bit-b.new)) < eps) break
		bit=b.new			
	}
	#return vector of m beta-coefficients, their variances, and the maximum log-likelihood function 
	return(c(bit,diag(iF),loglik.new))
}

if(normlow==1) X2=X[,1:2] else X2=X[,3:4]
uid=unique(persid);N=length(uid)
par(mfrow=c(1,2),mar=c(4.5,4.5,4,1),cex.lab=1.5,cex.main=1.25)
plot(1,1,type="n",xlim=c(0,1),ylim=c(0,1),xlab="False positive",ylab="Sensitivity",main=paste("ROC curve for",tit,"\nclassification using AFM image features",nam1,"and",nam2))
Xi=cbind(rep(1,nrow(X2)),X2)
out=singhit(y=cancer,id=persid,X=Xi,pr=prnt,eps=eps,maxit=maxit)
bit=out[1:3]
pri=YY=rep(NA,N)
for(i in 1:N)
{
	YY[i]=unique(cancer[persid==uid[i]])
	Xii=Xi[persid==uid[i],]
	ei=as.vector(exp(Xii%*%bit))
	qi=sum(log(1+ei))
	pri[i]=1-exp(-qi)				
}
spr1=sort(pri)
sens1=fp1=rep(NA,N)
AUC.onehit=0
for(i in 1:N)
{
	sens1[i]=sum(pri>=spr1[i] & YY==1)/sum(YY)
	fp1[i]=sum(pri>=spr1[i] & YY==0)/sum(1-YY)
	if(i>1) AUC.onehit=AUC.onehit+(fp1[i-1]-fp1[i])*sens1[i]	
}		
lines(c(fp1,0),c(sens1,0),type="s",lwd=3)
rug(side=1,fp1,ticksize=0.03)
rug(side=2,sens1,ticksize=0.03)
text(.5,.5,paste("AUC = ",round(AUC.onehit*100,1),"%",sep=""),cex=1.75)
	
Toter.onehit=1-sens1+fp1				
mToter.onehit=min(Toter.onehit)
opt.thr=spr1[Toter.onehit==mToter.onehit]
plot(spr1,Toter.onehit,type="s",ylim=c(0,1),lwd=3,xlab="Probability threshold",ylab="Classification error",main=paste("Classification error for",tit,"\nusing AFM image features",nam1,"and",nam2))
rug(side=1,spr1,ticksize=0.03)
rug(side=2,Toter.onehit,ticksize=0.03)		
points(opt.thr,mToter.onehit)
segments(opt.thr,mToter.onehit,opt.thr,-1,lty=2)
text(.2,.8,paste("Optimal probability threshold=",round(opt.thr,2),"\nMinimum classification error=",round(mToter.onehit,2),"\nAccuracy=",round(1-mToter.onehit,2)),adj=0,cex=1.5)
}
